import { renderizarVideo, getDuration } from "./render.js";
import { existsSync } from "fs";
import { spawn } from "child_process";

function ffprobeStreams(path: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn("ffprobe", [
      "-v", "error",
      "-show_entries", "stream=codec_type,codec_name",
      "-of", "default=noprint_wrappers=1",
      path
    ]);
    let out = "";
    proc.stdout.on("data", d => (out += d.toString()));
    proc.on("close", code => (code === 0 ? resolve(out) : reject(new Error("ffprobe falhou"))));
  });
}

async function run() {
  let passed = 0;
  let total = 0;
  const check = (label: string, cond: boolean) => {
    total++;
    console.log(`${cond ? "OK " : "FALHOU"} | ${label}`);
    if (cond) passed++;
  };

  const outputComMusica = "test-fixtures/output-com-musica.mp4";
  const outputSemMusica = "test-fixtures/output-sem-musica.mp4";

  // --- Teste 1: com música (testa o loop, já que música é mais curta que o vídeo) ---
  await renderizarVideo({
    videoPath: "test-fixtures/video.mp4",
    narrationPath: "test-fixtures/narracao.wav",
    musicPath: "test-fixtures/musica.wav",
    roteiro: "Você ainda usa aquela esponja velha que não tira a sujeira? Conheça essa fibra mágica",
    outputPath: outputComMusica
  });

  check("arquivo de saída (com música) foi criado", existsSync(outputComMusica));

  const durationComMusica = await getDuration(outputComMusica);
  const durationVideoOriginal = await getDuration("test-fixtures/video.mp4");
  check(
    `duração final bate com o vídeo original (${durationVideoOriginal.toFixed(1)}s)`,
    Math.abs(durationComMusica - durationVideoOriginal) < 0.5
  );

  const streamsComMusica = await ffprobeStreams(outputComMusica);
  check("tem stream de vídeo (h264)", streamsComMusica.includes("codec_name=h264"));
  check("tem stream de áudio (aac)", streamsComMusica.includes("codec_name=aac"));

  // --- Teste 2: sem música (só narração + legenda) ---
  await renderizarVideo({
    videoPath: "test-fixtures/video.mp4",
    narrationPath: "test-fixtures/narracao.wav",
    musicPath: null,
    roteiro: "Vídeo sem música de fundo, só narração e legenda",
    outputPath: outputSemMusica
  });

  check("arquivo de saída (sem música) foi criado", existsSync(outputSemMusica));
  const streamsSemMusica = await ffprobeStreams(outputSemMusica);
  check("sem música: ainda tem vídeo + áudio válidos", streamsSemMusica.includes("codec_name=h264") && streamsSemMusica.includes("codec_name=aac"));

  // --- Teste 3: roteiro vazio não quebra o render ---
  const outputSemLegenda = "test-fixtures/output-sem-legenda.mp4";
  await renderizarVideo({
    videoPath: "test-fixtures/video.mp4",
    narrationPath: "test-fixtures/narracao.wav",
    musicPath: null,
    roteiro: "",
    outputPath: outputSemLegenda
  });
  check("roteiro vazio não quebra o render", existsSync(outputSemLegenda));

  console.log(`\n${passed}/${total} casos passaram.`);
  if (passed !== total) process.exit(1);
}

run().catch(err => {
  console.error("Erro no teste:", err);
  process.exit(1);
});
