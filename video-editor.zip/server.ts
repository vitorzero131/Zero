import "dotenv/config";
import express from "express";
import multer from "multer";
import path from "path";
import fs, { existsSync, mkdirSync } from "fs";
import { randomUUID } from "crypto";
import { renderizarVideo } from "./render.js";

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

const UPLOAD_DIR = path.join(process.cwd(), "uploads");
const OUTPUT_DIR = path.join(process.cwd(), "outputs");
const MUSIC_DIR = path.join(process.cwd(), "music-library");

for (const dir of [UPLOAD_DIR, OUTPUT_DIR, MUSIC_DIR]) {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

const upload = multer({ dest: UPLOAD_DIR, limits: { fileSize: 200 * 1024 * 1024 } });

app.use(express.json());
app.use("/outputs", express.static(OUTPUT_DIR));

// --- Biblioteca de músicas por categoria ---

app.post("/api/music/upload", upload.single("file"), (req, res) => {
  try {
    const categoria = (req.body.categoria || "geral").toLowerCase().replace(/[^a-z0-9-]/g, "-");
    const file = req.file;
    if (!file) {
      res.status(400).json({ error: "Nenhum arquivo enviado." });
      return;
    }
    const categoriaDir = path.join(MUSIC_DIR, categoria);
    if (!existsSync(categoriaDir)) mkdirSync(categoriaDir, { recursive: true });

    const nomeFinal = `${Date.now()}-${file.originalname}`;
    const destino = path.join(categoriaDir, nomeFinal);
    fs.renameSync(file.path, destino);

    res.json({ categoria, arquivo: nomeFinal });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Erro ao salvar música." });
  }
});

app.get("/api/music", (_req, res) => {
  try {
    if (!existsSync(MUSIC_DIR)) {
      res.json({});
      return;
    }
    const categorias = fs.readdirSync(MUSIC_DIR).filter(f =>
      fs.statSync(path.join(MUSIC_DIR, f)).isDirectory()
    );
    const resultado: Record<string, string[]> = {};
    for (const cat of categorias) {
      resultado[cat] = fs.readdirSync(path.join(MUSIC_DIR, cat));
    }
    res.json(resultado);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Erro ao listar músicas." });
  }
});

// --- Renderização do vídeo final ---

const renderUpload = upload.fields([
  { name: "video", maxCount: 1 },
  { name: "narracao", maxCount: 1 },
  { name: "musica", maxCount: 1 } // upload avulso, alternativa a escolher da biblioteca
]);

app.post("/api/render", renderUpload, async (req, res) => {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  const cleanup: string[] = [];

  try {
    const videoFile = files?.video?.[0];
    const narracaoFile = files?.narracao?.[0];
    const musicaFile = files?.musica?.[0];
    const { roteiro, musicaCategoria, musicaArquivo } = req.body as {
      roteiro?: string;
      musicaCategoria?: string;
      musicaArquivo?: string;
    };

    if (!videoFile || !narracaoFile) {
      res.status(400).json({ error: "Envie pelo menos o vídeo e a narração." });
      return;
    }
    cleanup.push(videoFile.path, narracaoFile.path);

    let musicPath: string | null = null;
    if (musicaFile) {
      musicPath = musicaFile.path;
      cleanup.push(musicaFile.path);
    } else if (musicaCategoria && musicaArquivo) {
      const candidato = path.join(MUSIC_DIR, musicaCategoria, musicaArquivo);
      if (existsSync(candidato)) musicPath = candidato;
    }

    const outputId = randomUUID();
    const outputPath = path.join(OUTPUT_DIR, `${outputId}.mp4`);

    await renderizarVideo({
      videoPath: videoFile.path,
      narrationPath: narracaoFile.path,
      musicPath,
      roteiro: roteiro || "",
      outputPath
    });

    res.json({ id: outputId, url: `/outputs/${outputId}.mp4` });
  } catch (error: any) {
    console.error("[render] Erro:", error);
    res.status(500).json({ error: error.message || "Erro ao renderizar o vídeo." });
  } finally {
    for (const filePath of cleanup) {
      fs.unlink(filePath, () => {});
    }
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/", (_req, res) => {
  res.send(PAGE_HTML);
});

const PAGE_HTML = `<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Editor de Vídeo</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; background: #0b0b10; color: #eee; padding: 20px; max-width: 480px; margin: 0 auto; }
  h1 { font-size: 18px; }
  h2 { font-size: 15px; margin-top: 24px; border-top: 1px solid #333; padding-top: 14px; }
  label { display: block; font-size: 13px; color: #aaa; margin-top: 10px; margin-bottom: 4px; }
  input[type=file], input[type=text], select { width: 100%; padding: 10px; font-size: 14px; box-sizing: border-box; border-radius: 8px; border: 1px solid #444; background: #1a1a22; color: #fff; }
  textarea { width: 100%; padding: 10px; font-size: 14px; box-sizing: border-box; border-radius: 8px; border: 1px solid #444; background: #1a1a22; color: #fff; min-height: 70px; }
  button { width: 100%; padding: 12px; font-size: 15px; font-weight: bold; border-radius: 8px; border: none; background: #f0a020; color: #111; cursor: pointer; margin-top: 14px; }
  button.secondary { background: #333; color: #fff; }
  pre { background: #1a1a22; padding: 12px; border-radius: 8px; white-space: pre-wrap; word-break: break-word; font-size: 12px; }
  video { width: 100%; border-radius: 8px; margin-top: 10px; }
  .status { margin-top: 10px; font-size: 13px; color: #f0a020; }
</style>
</head>
<body>
  <h1>🎬 Editor de Vídeo</h1>

  <label>Vídeo (baixado, sem edição ainda)</label>
  <input type="file" id="video" accept="video/*" />

  <label>Narração (áudio gerado no ElevenLabs ou outro)</label>
  <input type="file" id="narracao" accept="audio/*" />

  <label>Roteiro (texto exato da narração, pra gerar a legenda sincronizada)</label>
  <textarea id="roteiro" placeholder="Cole aqui o mesmo texto que você usou pra gerar a narração"></textarea>

  <h2>🎵 Música de fundo</h2>
  <label>Categoria</label>
  <select id="categoriaMusica">
    <option value="">Nenhuma / escolher categoria depois</option>
  </select>
  <label>Faixa</label>
  <select id="faixaMusica">
    <option value="">-</option>
  </select>

  <label style="margin-top:16px">Ou sobe uma música avulsa (não fica salva na biblioteca)</label>
  <input type="file" id="musicaAvulsa" accept="audio/*" />

  <button onclick="renderizar()">🎬 Gerar vídeo</button>
  <div id="status" class="status"></div>
  <div id="resultado"></div>

  <h2>📁 Adicionar música à biblioteca</h2>
  <label>Categoria (ex: cozinha, tecnologia, pet, roupa)</label>
  <input type="text" id="novaCategoria" placeholder="cozinha" />
  <label>Arquivo de música</label>
  <input type="file" id="novoArquivoMusica" accept="audio/*" />
  <button class="secondary" onclick="uploadMusica()">📤 Enviar música pra biblioteca</button>
  <div id="statusMusica" class="status"></div>

  <script>
    async function carregarBiblioteca() {
      try {
        const r = await fetch('/api/music');
        const dados = await r.json();
        const selectCategoria = document.getElementById('categoriaMusica');
        selectCategoria.innerHTML = '<option value="">Nenhuma</option>';
        for (const cat of Object.keys(dados)) {
          const opt = document.createElement('option');
          opt.value = cat;
          opt.textContent = cat;
          selectCategoria.appendChild(opt);
        }
        selectCategoria.onchange = () => atualizarFaixas(dados);
        window._biblioteca = dados;
      } catch (e) {
        console.error(e);
      }
    }

    function atualizarFaixas(dados) {
      const cat = document.getElementById('categoriaMusica').value;
      const selectFaixa = document.getElementById('faixaMusica');
      selectFaixa.innerHTML = '';
      const arquivos = dados[cat] || [];
      if (arquivos.length === 0) {
        selectFaixa.innerHTML = '<option value="">Nenhuma música nessa categoria ainda</option>';
        return;
      }
      for (const arq of arquivos) {
        const opt = document.createElement('option');
        opt.value = arq;
        opt.textContent = arq;
        selectFaixa.appendChild(opt);
      }
    }

    async function uploadMusica() {
      const categoria = document.getElementById('novaCategoria').value.trim();
      const arquivo = document.getElementById('novoArquivoMusica').files[0];
      const status = document.getElementById('statusMusica');
      if (!categoria || !arquivo) {
        status.textContent = 'Preenche categoria e escolhe o arquivo.';
        return;
      }
      status.textContent = 'Enviando...';
      const form = new FormData();
      form.append('categoria', categoria);
      form.append('file', arquivo);
      try {
        const r = await fetch('/api/music/upload', { method: 'POST', body: form });
        const data = await r.json();
        if (!r.ok) { status.textContent = 'Erro: ' + data.error; return; }
        status.textContent = 'Música salva em "' + data.categoria + '"!';
        carregarBiblioteca();
      } catch (e) {
        status.textContent = 'Erro: ' + e.message;
      }
    }

    async function renderizar() {
      const video = document.getElementById('video').files[0];
      const narracao = document.getElementById('narracao').files[0];
      const roteiro = document.getElementById('roteiro').value;
      const musicaCategoria = document.getElementById('categoriaMusica').value;
      const musicaArquivo = document.getElementById('faixaMusica').value;
      const musicaAvulsa = document.getElementById('musicaAvulsa').files[0];

      const status = document.getElementById('status');
      const resultado = document.getElementById('resultado');

      if (!video || !narracao) {
        status.textContent = 'Precisa do vídeo e da narração no mínimo.';
        return;
      }

      status.textContent = 'Renderizando... isso pode levar um tempinho, não fecha a página.';
      resultado.innerHTML = '';

      const form = new FormData();
      form.append('video', video);
      form.append('narracao', narracao);
      form.append('roteiro', roteiro);
      if (musicaAvulsa) {
        form.append('musica', musicaAvulsa);
      } else if (musicaCategoria && musicaArquivo) {
        form.append('musicaCategoria', musicaCategoria);
        form.append('musicaArquivo', musicaArquivo);
      }

      try {
        const r = await fetch('/api/render', { method: 'POST', body: form });
        const data = await r.json();
        if (!r.ok) {
          status.textContent = '';
          resultado.innerHTML = '<pre>Erro: ' + (data.error || 'falha desconhecida') + '</pre>';
          return;
        }
        status.textContent = 'Pronto!';
        resultado.innerHTML =
          '<video controls src="' + data.url + '"></video>' +
          '<a href="' + data.url + '" download><button>⬇️ Baixar vídeo</button></a>';
      } catch (e) {
        status.textContent = '';
        resultado.innerHTML = '<pre>Erro: ' + e.message + '</pre>';
      }
    }

    carregarBiblioteca();
  </script>
</body>
</html>`;

app.listen(PORT, "0.0.0.0", () => {
  console.log(`[server] Rodando em http://localhost:${PORT}`);
});
