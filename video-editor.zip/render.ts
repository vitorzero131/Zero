import { spawn } from "child_process";
import { gerarBlocosDeLegenda, escaparTextoFfmpeg } from "./captions.js";

export interface RenderOptions {
  videoPath: string;
  narrationPath: string;
  musicPath: string | null;
  roteiro: string;
  outputPath: string;
  musicVolume?: number; // 0 a 1, padrão 0.15 (bem baixa, embaixo da narração)
}

function runFfprobe(args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn("ffprobe", args);
    let stdout = "";
    let stderr = "";
    proc.stdout.on("data", d => (stdout += d.toString()));
    proc.stderr.on("data", d => (stderr += d.toString()));
    proc.on("close", code => {
      if (code === 0) resolve(stdout.trim());
      else reject(new Error(`ffprobe falhou (código ${code}): ${stderr}`));
    });
  });
}

export async function getDuration(filePath: string): Promise<number> {
  const out = await runFfprobe([
    "-v", "error",
    "-show_entries", "format=duration",
    "-of", "default=noprint_wrappers=1:nokey=1",
    filePath
  ]);
  const duration = parseFloat(out);
  if (isNaN(duration)) throw new Error(`Não consegui ler a duração de ${filePath}`);
  return duration;
}

function runFfmpeg(args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn("ffmpeg", args);
    let stderr = "";
    proc.stderr.on("data", d => (stderr += d.toString()));
    proc.on("close", code => {
      if (code === 0) resolve();
      else reject(new Error(`ffmpeg falhou (código ${code}):\n${stderr.slice(-2000)}`));
    });
  });
}

/**
 * Monta a cadeia de filtros drawtext, um por bloco de legenda, cada um
 * visível só na janela de tempo dele (enable=between(t,start,end)).
 */
function montarFiltroLegendas(roteiro: string, duracaoSec: number): string {
  const blocos = gerarBlocosDeLegenda(roteiro, duracaoSec);
  if (blocos.length === 0) return "";

  return blocos
    .map(b => {
      const texto = escaparTextoFfmpeg(b.text);
      return (
        `drawtext=text='${texto}':fontcolor=white:fontsize=52:` +
        `borderw=3:bordercolor=black:` +
        `x=(w-text_w)/2:y=h-280:` +
        `enable='between(t,${b.startSec.toFixed(2)},${b.endSec.toFixed(2)})'`
      );
    })
    .join(",");
}

/**
 * Junta vídeo + narração + música (opcional) + legenda queimada, num
 * único arquivo final. A narração substitui o áudio original do vídeo.
 * A música (se houver) toca por baixo, em volume baixo, cortada/repetida
 * pra bater com a duração do vídeo final.
 */
export async function renderizarVideo(opts: RenderOptions): Promise<void> {
  const musicVolume = opts.musicVolume ?? 0.15;
  const videoDuration = await getDuration(opts.videoPath);
  const narrationDuration = await getDuration(opts.narrationPath);

  // Duração final = a do vídeo (não estica nem corta o vídeo pra caber a narração).
  const finalDuration = videoDuration;

  const filtroLegenda = montarFiltroLegendas(opts.roteiro, Math.min(narrationDuration, finalDuration));

  const inputs: string[] = ["-i", opts.videoPath, "-i", opts.narrationPath];
  if (opts.musicPath) {
    inputs.push("-stream_loop", "-1", "-i", opts.musicPath);
  }

  const filterParts: string[] = [];

  // Vídeo: aplica a cadeia de legendas (se houver blocos) direto no stream 0:v.
  if (filtroLegenda) {
    filterParts.push(`[0:v]${filtroLegenda}[vout]`);
  } else {
    filterParts.push(`[0:v]null[vout]`);
  }

  // Áudio: narração + música (se houver), com a música bem mais baixa.
  if (opts.musicPath) {
    filterParts.push(
      `[2:a]volume=${musicVolume},atrim=0:${finalDuration.toFixed(2)}[music]`,
      `[1:a]atrim=0:${finalDuration.toFixed(2)}[narr]`,
      `[narr][music]amix=inputs=2:duration=first:dropout_transition=0[aout]`
    );
  } else {
    filterParts.push(`[1:a]atrim=0:${finalDuration.toFixed(2)}[aout]`);
  }

  const filterComplex = filterParts.join(";");

  const args = [
    "-y",
    ...inputs,
    "-filter_complex", filterComplex,
    "-map", "[vout]",
    "-map", "[aout]",
    "-t", finalDuration.toFixed(2),
    "-c:v", "libx264",
    "-preset", "veryfast",
    "-crf", "23",
    "-c:a", "aac",
    "-b:a", "192k",
    opts.outputPath
  ];

  await runFfmpeg(args);
}
