export interface CaptionBlock {
  text: string;
  startSec: number;
  endSec: number;
}

/**
 * Divide o roteiro em blocos de legenda (3-5 palavras cada) e distribui
 * o tempo proporcionalmente ao tamanho de cada bloco (blocos com mais
 * letras ficam mais tempo na tela), ocupando a duração total informada.
 */
export function gerarBlocosDeLegenda(
  roteiro: string,
  duracaoTotalSec: number,
  palavrasPorBloco = 4
): CaptionBlock[] {
  const palavras = roteiro
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (palavras.length === 0 || duracaoTotalSec <= 0) return [];

  const blocosTexto: string[] = [];
  for (let i = 0; i < palavras.length; i += palavrasPorBloco) {
    blocosTexto.push(palavras.slice(i, i + palavrasPorBloco).join(" "));
  }

  const totalCaracteres = blocosTexto.reduce((soma, b) => soma + b.length, 0);

  const blocos: CaptionBlock[] = [];
  let tempoAcumulado = 0;

  for (let i = 0; i < blocosTexto.length; i++) {
    const texto = blocosTexto[i];
    const proporcao = totalCaracteres > 0 ? texto.length / totalCaracteres : 1 / blocosTexto.length;
    const duracaoBloco = duracaoTotalSec * proporcao;

    const startSec = tempoAcumulado;
    const endSec =
      i === blocosTexto.length - 1 ? duracaoTotalSec : tempoAcumulado + duracaoBloco;

    blocos.push({ text: texto, startSec, endSec });
    tempoAcumulado = endSec;
  }

  return blocos;
}

/**
 * Escapa caracteres especiais do ffmpeg drawtext (aspas simples, dois
 * pontos, barra invertida) pra não quebrar o filtro.
 */
export function escaparTextoFfmpeg(texto: string): string {
  return texto
    .replace(/\\/g, "\\\\")
    .replace(/:/g, "\\:")
    .replace(/'/g, "\u2019") // troca aspas simples por aspas tipográficas, evita quebrar o filtro
    .replace(/%/g, "\\%");
}
