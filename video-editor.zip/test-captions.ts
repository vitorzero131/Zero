import { gerarBlocosDeLegenda, escaparTextoFfmpeg } from "./captions.js";

let passed = 0;
let total = 0;
const check = (label: string, cond: boolean) => {
  total++;
  console.log(`${cond ? "OK " : "FALHOU"} | ${label}`);
  if (cond) passed++;
};

const roteiro = "Você ainda usa aquela esponja velha que não tira a sujeira? Conheça essa fibra mágica que limpa qualquer panela em segundos";
const duracao = 14;

const blocos = gerarBlocosDeLegenda(roteiro, duracao);

console.log("\nBlocos gerados:");
for (const b of blocos) {
  console.log(`  [${b.startSec.toFixed(2)}s - ${b.endSec.toFixed(2)}s] "${b.text}"`);
}

check("gerou pelo menos 1 bloco", blocos.length > 0);
check("primeiro bloco começa em 0", blocos[0].startSec === 0);
check("último bloco termina exatamente na duração total", Math.abs(blocos[blocos.length - 1].endSec - duracao) < 0.001);

// Confere que não tem sobreposição nem buraco entre blocos
let semSobreposicao = true;
for (let i = 1; i < blocos.length; i++) {
  if (Math.abs(blocos[i].startSec - blocos[i - 1].endSec) > 0.001) {
    semSobreposicao = false;
  }
}
check("blocos são contínuos, sem sobreposição nem buraco", semSobreposicao);

// Confere que juntar todo o texto dos blocos reconstrói o roteiro original
const textoReconstruido = blocos.map(b => b.text).join(" ");
check("texto reconstruído bate com o roteiro original", textoReconstruido === roteiro.trim());

// Teste de roteiro vazio
const blocosVazio = gerarBlocosDeLegenda("", 10);
check("roteiro vazio retorna lista vazia (não quebra)", blocosVazio.length === 0);

// Teste de duração zero
const blocosDuracaoZero = gerarBlocosDeLegenda("teste", 0);
check("duração zero retorna lista vazia (não quebra)", blocosDuracaoZero.length === 0);

// Teste de escape de caracteres especiais do ffmpeg
const escapado = escaparTextoFfmpeg("Não é: incrível? 50% off, 'oferta' aqui");
console.log(`\nTexto escapado: ${escapado}`);
check("escapa dois pontos", escapado.includes("\\:"));
check("escapa porcentagem", escapado.includes("\\%"));
check("não quebra com aspas simples (substitui por tipográfica)", !escapado.includes("'"));

console.log(`\n${passed}/${total} casos passaram.`);
if (passed !== total) process.exit(1);
