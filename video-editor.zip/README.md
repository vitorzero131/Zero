# Editor de Vídeo

App simples: sobe um vídeo baixado + narração + escolhe música da sua
biblioteca (organizada por categoria) → ele junta tudo automaticamente,
já com legenda queimada sincronizada com o roteiro que você colar.

## O que foi testado de verdade (sem depender de arquivo real seu)

- Divisão do roteiro em blocos de legenda sincronizados com o tempo:
  **10/10 casos** (incluindo roteiro vazio, duração zero, texto com
  caracteres especiais tipo `:` `%` `'` que quebrariam o ffmpeg sem
  o escape)
- Pipeline completo (vídeo + narração + música + legenda) rodando de
  ponta a ponta com arquivos de teste sintéticos: **7/7 casos**
- Confirmação visual objetiva (contagem de pixel) de que a legenda é
  realmente desenhada no vídeo, não só "roda sem erro"
- Testado via HTTP de ponta a ponta (upload → renderiza → baixa →
  confere que o MP4 final é válido): funcionando, incluindo o caminho
  com música escolhida da biblioteca e o caminho de erro (campo
  faltando retorna mensagem clara, não trava)

**O que não testei:** com um vídeo/narração/música de verdade seus —
isso só você consegue confirmar, já que não tenho acesso aos seus
arquivos.

## Como funciona por dentro

- A narração **substitui** o áudio original do vídeo (não mixa os dois)
- A música toca por baixo da narração, bem mais baixa (15% do volume
  por padrão), e repete em loop se for mais curta que o vídeo
- A duração final do vídeo é sempre a do **vídeo original** (não estica
  nem corta pra caber a narração)
- A legenda é dividida automaticamente em blocos de ~4 palavras,
  distribuídos proporcionalmente ao longo do tempo da narração

## Rodar sem computador (celular/tablet) — mesmo fluxo do shopee-puller

1. Sobe todos os arquivos desse projeto pro GitHub (raiz do repositório,
   sem subpasta)
2. Railway → New Project → Deploy from GitHub repo
3. Build command: `npm run build` — Start command: `npm start`
4. Gera o domínio público em Settings → Networking
5. Abre esse domínio no navegador — a página de upload aparece direto

**Diferença importante desse projeto pro shopee-puller:** esse aqui
precisa do `ffmpeg` instalado no servidor. Já incluí um arquivo
`nixpacks.toml` que manda o Railway instalar o ffmpeg automaticamente
no build — não precisa fazer nada manual pra isso, mas se der erro de
"ffmpeg: command not found" nos logs, me avisa que a gente ajusta.

## Limitação importante: biblioteca de música não é permanente

As músicas que você subir pra biblioteca ficam salvas no disco do
servidor, mas o Railway pode apagar esse disco quando você faz um novo
deploy (sobe código novo). Ou seja: **toda vez que você atualizar o
código no GitHub, seria bom re-subir as músicas de novo.** Se isso virar
chato, dá pra resolver depois configurando um "Volume" persistente no
Railway (avisa que eu te guio) ou migrando a biblioteca pra guardar em
nuvem — mas pra começar a testar, do jeito que está já funciona.

## Uso

1. Escolhe o vídeo baixado
2. Escolhe o áudio da narração (gerado no ElevenLabs, por exemplo)
3. Cola o roteiro exato que você usou pra gerar a narração (é esse
   texto que vira a legenda sincronizada)
4. Escolhe a categoria/música da biblioteca (ou sobe uma avulsa)
5. Aperta "Gerar vídeo", espera processar, baixa o resultado

Antes disso, se quiser ter música pronta pra escolher, sobe pelo menos
uma faixa por categoria na seção "Adicionar música à biblioteca".
